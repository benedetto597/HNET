# -*- coding: utf-8 -*-

from . import requisiciones
from . import requisiciones_condensadas
from . import purchase_order_inherit
from . import account_tax
from . import stock_location_inherit
from . import product


