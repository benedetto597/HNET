# -*- coding: utf-8 -*-
{
    'name': "Menu Aprobaciones",
    'summary': "Addon secundario para agrupar todas las opciones de correo para los diferentes addons de aprobaciones para el HVDA.",
    'description': "Addon secundario para agrupar todas las opciones de correo para los diferentes addons de aprobaciones para el HVDA.",
    'author': "HNET",
    'website': "http://www.hnetw.com",
    'category': 'HNET',
    'version': '0.1',
    'depends': ['base'],
    'data': [
        'views/res_company_view.xml',
    ],
}
