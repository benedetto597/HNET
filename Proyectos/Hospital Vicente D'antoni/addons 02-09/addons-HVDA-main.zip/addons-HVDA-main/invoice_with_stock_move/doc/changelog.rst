`1.0.2                                                        [05/04/2020]`
***************************************************************************
- Imprvoed code for allowing user setting picking type.
- Bugfix for completion of rder in case lot on product.

`1.0.1                                                        [03/10/2020]`
***************************************************************************
- Launched Module for v14