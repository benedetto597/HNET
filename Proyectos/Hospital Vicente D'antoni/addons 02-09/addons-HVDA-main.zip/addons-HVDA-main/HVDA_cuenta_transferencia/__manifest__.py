# -*- coding: utf-8 -*-
{
    'name': "HVDA - Cuenta Analitica en Transferencias",
    'summary': "Añadir Cuenta analitica automaticamente",
    'description': "Añadir Cuenta analitica automaticamente",
    'author': "HNET",
    'website': "http://www.hnetw.com",
    'category': 'Stock',
    'version': '0.1',
    'depends': ['base', 'stock', 'account'],
    'data': [
        'views/views.xml',
    ],
}
