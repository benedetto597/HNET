# -*- coding: utf-8 -*-
{
    'name': "Pricelist Categories",
    'summary': "Agregar Varias categorias",
    'description': "Agregar Varias categorias",
    'author': "HNET",
    'website': "http://www.hnetw.com",
    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base', 'product'],
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
    ],
}
