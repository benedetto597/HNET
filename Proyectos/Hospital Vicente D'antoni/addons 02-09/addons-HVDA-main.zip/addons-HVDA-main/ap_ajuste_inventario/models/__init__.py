# -*- coding: utf-8 -*-

from . import stock_inventory
from . import res_company