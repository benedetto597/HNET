{
    'name': "ventas: Margen en Porcentaje",
    'summary': "Mostrar el margen de venta en porcentaje",
    'description': "Mostrar el margen de venta en porcentaje",
    'author': "HNET",
    'website': "http://www.hnetw.com",
    'category': 'Sales',
    'version': '0.1',
    'depends': ['base', 'sale', 'sale_margin'],
    'data': [
        'views/views.xml',
    ],
}
