{
    'name': "Resumen Costo entregadas vs presupuestadas",
    'summary': "Resumen Costo entregadas vs presupuestadas",
    'description': "Resumen Costo entregadas vs presupuestadas",
    'author': "HNET",
    'website': "http://www.hnetw.com",
    'category': 'Sales',
    'version': '13.0.1',
    'depends': ['base', 'sale', 'project', 'sale_margin', 'stock'],
    'data': [
        'views/project_project_views.xml',
        'views/stock_move_view.xml',
        'views/stock_picking_view.xml',
    ],
}
