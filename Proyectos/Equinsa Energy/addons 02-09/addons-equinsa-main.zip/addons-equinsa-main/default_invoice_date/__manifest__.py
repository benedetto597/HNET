{
    'name': "Fecha de Factura por defecto",
    'summary': "Fecha de Factura por defecto al dia que se creo",
    'description': "Fecha de Factura por defecto al dia que se creo",
    'author': "HNET",
    'website': "http://www.hnetw.com",
    'category': 'accounting',
    'version': '1.0',
    'depends': ['base', 'account'],
    'data': [],
}
