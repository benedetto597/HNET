{
    'name': "Cancelar Cotizaciones Expiradas",
    'summary': "Cancelar Cotizaciones expiradas",
    'description': "Cancelar Cotizaciones expiradas",
    'author': "HNET",
    'website': "http://www.hnetw.com",
    'category': 'Sale',
    'version': '0.1',
    'depends': ['base', 'sale'],
    'data': [
        'data/cancel_cron.xml',
    ],
}
