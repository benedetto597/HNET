{
    'name': "Responsable por defecto",
    'summary': "Responsable por defecto al crear transferencia",
    'description': "Responsable por defecto al crear transferencia",
    'author': "HNET",
    'website': "http://www.hnetw.com",
    'category': 'Stock',
    'version': '1.0',
    'depends': ['base', 'stock'],
    'data': [],
}
