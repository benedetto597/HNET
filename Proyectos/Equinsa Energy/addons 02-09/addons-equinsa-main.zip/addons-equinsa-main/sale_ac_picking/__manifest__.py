{
    'name': "Asignar cuenta analitica en Envio",
    'summary': "Asignar cuenta analitica de la cotizacion en el Envio",
    'description': "Asignar cuenta analitica de la cotizacion en el Envio",
    'author': "HNET",
    'website': "http://www.hnetw.com",
    'category': 'Sale',
    'version': '0.1',
    'depends': ['base', 'sale', 'stock_account'],
    'data': [
        'views/views.xml',
    ],
}
