{
    'name': "Campos Calculados en Cotizaciones",
    'summary': "Campos Calculados en Cotizaciones solicitados por EQUINSA",
    'description': "Campos Calculados en Cotizaciones solicitados por EQUINSA",
    'author': "HNET",
    'website': "http://www.hnetw.com",
    'category': 'Sale',
    'version': '13.0.1',
    'depends': ['base', 'sale', 'sale_commission'],
    'data': [
        'views/views.xml',
    ],
}
