# -*- coding: utf-8 -*-

from . import pos_cai_fields
from . import pos_ticket_custom