# -*- coding: utf-8 -*-
from . import account_bank_statement_inherit
from . import account_payment_register_inherit
from . import stock_picking_inherit
from . import crm_team_inherit
from . import sale_order_inherit
from . import salesteam_config
from . import salesteam_session
from . import salesteam_payment